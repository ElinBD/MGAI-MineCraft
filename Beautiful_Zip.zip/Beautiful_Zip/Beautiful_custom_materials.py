# import utilityFunctions as utilityFunctions
# import itertools
# import numpy as np

# from pymclevel.biome_types import biome_types
# from pymclevel.box import BoundingBox
# from pymclevel import alphaMaterials

# from Beautiful_meta_analysis import *

# inputs = (
#     ("Use metadata for finding map type", "label"),
#     ("Creator: Elin", "label")
# )

# range_dicts = {'grass': {low: ,
#                          medium: ,
#                          high: },
#                'air': {low: ,
#                          medium: ,
#                          high: },
#                 'grass': {low: ,
#                          medium: ,
#                          high: },'grass': {low: ,
#                          medium: ,
#                          high: },'grass': {low: ,
#                          medium: ,
#                          high: },'grass': {low: ,
#                          medium: ,
#                          high: },'grass': {low: ,
#                          medium: ,
#                          high: },'grass': {low: ,
#                          medium: ,
#                          high: },
                
#                          }



# # small def: flat land
# # high def: high land
# def get_house_types():
#     total_blocks = box

#     block_freq = get_block_type_counts(level, box, options)
    
#     for biome_types in block_types:
#         freq = block_freq[biome_types]
#         ratio = freq/total_blocks

    
#     grass_ranges_dict = 
#     range_dict = 
#     range_dict = 


